create
    definer = u1063682_one_cod@`%` procedure deleteCheckOrder(IN id_order int)
begin
    delete from checkOrder where id = id_order;
end;

