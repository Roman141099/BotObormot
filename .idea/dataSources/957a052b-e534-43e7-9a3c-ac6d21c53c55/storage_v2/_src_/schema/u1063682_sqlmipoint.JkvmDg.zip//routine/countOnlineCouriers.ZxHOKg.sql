create
    definer = u1063682_one_cod@`%` procedure countOnlineCouriers()
begin
    select count(id) from couriers where online;
end;

