create
    definer = u1063682_one_cod@`%` procedure getOrderData(IN id_order int)
begin
    select o.id_order     as id_order,
           o.id_courier   as id_courier,
           o.id_building  as id_building,
           v.name         as vehicle,
           o.courier_lat  as courier_lat,
           o.courier_lon  as courier_lon,
           o.building_lat as building_lat,
           o.building_lon as building_lon,
           o.finish_lat   as finish_lat,
           o.finish_lon   as finish_lon,
           o.order_taken  as order_taken
    from (select o.id_order    as id_order,
                 o.id_courier  as id_courier,
                 o.id_building as id_building,
                 o.vehicle     as vehicle,
                 o.courier_lat as courier_lat,
                 o.courier_lon as courier_lon,
                 b.latitude    as building_lat,
                 b.longitude   as building_lon,
                 o.finish_lat  as finish_lat,
                 o.finish_lon  as finish_lon,
                 o.order_taken as order_taken
          from (select o.id_order       as id_order,
                       o.id_courier     as id_courier,
                       o.id_building    as id_building,
                       o.finish_lat     as finish_lat,
                       o.finish_lon     as finish_lon,
                       c.vehicle        as vehicle,
                       c.last_longitude as courier_lon,
                       c.last_latitude  as courier_lat,
                       o.order_taken    as order_taken
                from (select o.id          as id_order,
                             o.courier_id  as id_courier,
                             o.stock       as id_building,
                             o.latitude    as finish_lat,
                             o.longitude   as finish_lon,
                             o.order_taken as order_taken
                      from checkOrder c
                               inner join orders o on c.id = o.id
                      where c.id = id_order) o
                         inner join couriers c on c.id = o.id_courier) o
                   inner join buildings b on o.id_building = b.id) o
             inner join vehicles v on o.vehicle = v.id;
end;

