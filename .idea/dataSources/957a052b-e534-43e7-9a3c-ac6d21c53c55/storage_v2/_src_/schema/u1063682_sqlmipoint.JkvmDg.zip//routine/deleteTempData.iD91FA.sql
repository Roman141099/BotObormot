create
    definer = u1063682_one_cod@`%` procedure deleteTempData(IN id_temp int)
begin
    delete from tempOrder where id = id_temp;
end;

